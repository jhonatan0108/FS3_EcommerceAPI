﻿namespace EcommerceAPI.Configuracion.Container
{
    public class PerfilAutoMapper
    {
    }
}
